<?php
{

global $smcFunc;

///////////////////////////////////////////
// Add data to messages table

$result = $smcFunc['db_query']('', "SHOW COLUMNS FROM {db_prefix}messages LIKE 'hiddenOption'");
if ($smcFunc['db_fetch_assoc']($result) == 0) {
	$smcFunc['db_query']('', "ALTER TABLE {db_prefix}messages ADD `hiddenOption` TINYINT( 4 ) UNSIGNED NOT NULL DEFAULT '0'");
	$smcFunc['db_query']('', "ALTER TABLE {db_prefix}messages Add `hiddenValue` MEDIUMINT( 8 ) UNSIGNED NOT NULL DEFAULT '0'");
}

$result = $smcFunc['db_query']('', "SHOW COLUMNS FROM {db_prefix}messages LIKE 'hiddenInfo'");
if ($smcFunc['db_fetch_assoc']($result) == 0)
	$smcFunc['db_query']('', "ALTER TABLE {db_prefix}messages ADD `hiddenInfo` TEXT NOT NULL DEFAULT ''");

///////////////////////////////////////////
// Add data to settings table

$result = $smcFunc['db_query']('', "SELECT `variable` FROM {db_prefix}settings WHERE `variable` LIKE 'allow_hiddenPost'");
if ($smcFunc['db_fetch_assoc']($result) == 0) {
	$smcFunc['db_query']('', "INSERT INTO {db_prefix}settings (`variable`, `value`) 
		VALUES ('allow_hiddenPost', '1'), 
			('show_hiddenMessage', '1'), 
			('max_hiddenValue', '500'),
			('show_hiddenColor', 'red')");
}

$result = $smcFunc['db_query']('', "SELECT `variable` FROM {db_prefix}settings WHERE `variable` LIKE 'hidden_info_length'");
if ($smcFunc['db_fetch_assoc']($result) == 0) {
	$smcFunc['db_query']('', "INSERT INTO {db_prefix}settings (`variable`, `value`) 
		VALUES ('hidden_info_length', '500')");
}

///////////////////////////////////////////
// Add permissions

$result = $smcFunc['db_query']('', "SELECT `permission` FROM {db_prefix}board_permissions WHERE `permission` LIKE 'hide_post_own'");
if ($smcFunc['db_fetch_assoc']($result) == 0) {

	// Build group list
	$result = $smcFunc['db_query']('', "SELECT id_group FROM {db_prefix}membergroups WHERE min_posts < 0 AND id_group > 1");
	$groups = array(0); // Don't include guest
	while ($row = $smcFunc['db_fetch_assoc']($result))
		$groups[] = $row['id_group'];
	$smcFunc['db_free_result']($result);

	// Build profile list
	$result = $smcFunc['db_query']('', "SELECT id_profile FROM {db_prefix}permission_profiles WHERE 1");
	$profiles = array();
	while ($row = $smcFunc['db_fetch_assoc']($result))
		$profiles[] = $row['id_profile'];
	$smcFunc['db_free_result']($result);

	// Build & execute add permission query
	$inserts = array();
	foreach ($profiles as $p) {
		foreach ($groups as $g) {
			$inserts[] = array($g,$p,'hide_post_own',1);
			$inserts[] = array($g,$p,'hide_post_any',1);
			$inserts[] = array($g,$p,'view_hidden_msg',1);
		  }
		// Moderators & Global Moderators
		$inserts[] = array(2,$p,'view_hidden_post',1);
		$inserts[] = array(3,$p,'view_hidden_post',1);
	}
	
	$smcFunc['db_insert']('insert',
		'{db_prefix}board_permissions',
		array('id_group' => 'int', 'id_profile' => 'int', 'permission' => 'string', 'add_deny' => 'int'),
		$inserts,
		array('id_group', 'id_profile', 'permission')
	);
	
}

}

?>
