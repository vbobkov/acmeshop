<?php
// Version: 1.0.5; Hide Post

function template_main()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

	echo '
<table width="100%" border="0" cellspacing="0" cellpadding="3">
	<tr>
		<td>', theme_linktree(), '</td>
	</tr>
</table>

<table width="100%" cellpadding="3" cellspacing="0" border="0" class="tborder" style="margin-bottom: 1ex;">
	<tr>
		<td align="left" class="catbg" height="30">
			<table border="0" width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td valign="middle"><b>' . $txt[139] . ':</b> ' . $context['page_index'] . '</td>
					<td valign="middle" align="right">' . $context['view_hidden_post_info'] . '</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<table border="0" width="100%" cellspacing="0" cellpadding="0" class="bordercolor" style="margin-bottom: 1ex;">
	<tr><td>
		<table border="0" width="100%" cellspacing="1" cellpadding="4" class="bordercolor">
			<tr class="titlebg">';
	if (!empty($context['topics']))
		echo '
				<td width="8%" colspan="2">&nbsp;</td>
				<td width="36%"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=subject', $context['sort_by'] == 'subject' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt[70], $context['sort_by'] == 'subject' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="8%"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=board', $context['sort_by'] == 'board' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt['smf82'], $context['sort_by'] == 'board' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="8%"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=starter', $context['sort_by'] == 'starter' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt[109], $context['sort_by'] == 'starter' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="4%" align="center"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=hidden_option', $context['sort_by'] == 'hidden_option' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt['hide_method'], $context['sort_by'] == 'hidden_Option' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="4%" align="center"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=hidden_value', $context['sort_by'] == 'hidden_value' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt['hide_value'], $context['sort_by'] == 'hidden_value' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="4%" align="center"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=replies', $context['sort_by'] == 'replies' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt[110], $context['sort_by'] == 'replies' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="4%" align="center"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=views', $context['sort_by'] == 'views' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt[301], $context['sort_by'] == 'views' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>
				<td width="24%"><a href="', $scripturl, '?action=hidepost', $context['querystring_board_limits'], ';sort=last_post', $context['sort_by'] == 'last_post' && $context['sort_direction'] == 'up' ? ';desc' : '', '">', $txt[111], $context['sort_by'] == 'last_post' ? ' <img src="' . $settings['images_url'] . '/sort_' . $context['sort_direction'] . '.gif" alt="" border="0" />' : '', '</a></td>';
	else
		echo '
				<td width="100%" colspan="7">', $txt[151] , '</td>';
	echo '
			</tr>';

	foreach ($context['topics'] as $topic)
	{
		echo '
			<tr>
				<td class="windowbg2" valign="middle" align="center" width="4%">
					<img src="' . $settings['images_url'] . '/topic/' . $topic['class'] . '.gif" alt="" /></td>
				<td class="windowbg2" valign="middle" align="center" width="4%">
					<img src="' . $topic['first_post']['icon_url'] . '" alt="" border="0" align="middle" /></td>
				<td class="windowbg" valign="middle" width="36%">
					' . $topic['first_post']['link'] . '<span class="smalltext">';
		if ($topic['new'] && $context['user']['is_logged'])
			echo '
					<a href="', $topic['new_href'], '"><img src="', $settings['images_url'], '/', $context['user']['language'], '/new.gif" alt="', $txt[302], '" border="0" /></a>';
		echo '
  		 	</span>
					</td>
				<td class="windowbg2" valign="middle" width="8%">
					', $topic['board']['link'], '</td>
				<td class="windowbg2" valign="middle" width="8%">
					' . $topic['first_post']['member']['link'] . '</td>
				<td class="windowbg" valign="middle" width="4%" align="center">
					' . $topic['hidden_option'] . '</td>
				<td class="windowbg" valign="middle" width="4%" align="center">
					' . $topic['hidden_value'] . '</td>
				<td class="windowbg" valign="middle" width="4%" align="center">
					' . $topic['replies'] . '</td>
				<td class="windowbg" valign="middle" width="4%" align="center">
					' . $topic['views'] . '</td>
				<td class="windowbg2" valign="middle" width="24%">
					<a href="', $topic['last_post']['href'], '"><img src="', $settings['images_url'], '/icons/last_post.gif" alt="', $txt[111], '" title="', $txt[111], '" border="0" style="float: right;" /></a>
					<span class="smalltext">
						', $topic['last_post']['time'], ' 
						', $txt[525], ' ', $topic['last_post']['member']['link'], '
					</span></td>
			</tr>';
	}

	echo '
		</table>
	</td></tr>
</table>

<table width="100%" cellpadding="3" cellspacing="0" border="0" class="tborder" style="margin-bottom: 1ex;">
	<tr>
		<td align="left" class="catbg" height="30">
			<table border="0" width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td valign="middle"><b>' . $txt[139] . ':</b> ' . $context['page_index'] . '</td>
					<td valign="middle" align="right">' . $context['view_hidden_post_info'] . '</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<table cellpadding="0" cellspacing="0" width="55%">
	<tr>
		<td class="smalltext" align="left" style="padding-top: 1ex;">', !empty($modSettings['enableParticipation']) ? '
			<img src="' . $settings['images_url'] . '/topic/normal_post.gif" alt="" align="middle" /> ' . $txt[457] . '<br />
			<img src="' . $settings['images_url'] . '/topic/hot_post.gif" alt="" align="middle" /> ' . $txt[454] . '<br />
			<img src="' . $settings['images_url'] . '/topic/veryhot_post.gif" alt="" align="middle" /> ' . $txt[455] . '
			<br/>' . (empty($modSettings['enableChest']) ? '' : '<img src="' . $settings['images_url'] . '/topic/chest_post.gif" alt="" align="middle" /> ' . $txt['legend_chest'] ) . '
		</td>
		<td class="smalltext" align="left" valign="top" style="padding-top: 1ex;">
			<img src="' . $settings['images_url'] . '/topic/my_normal_post.gif" alt="" align="middle" /> ' . $txt['participation_caption'] . '<br />' : '', '
			<img src="' . $settings['images_url'] . '/topic/normal_post_locked.gif" alt="" align="middle" /> ' . $txt[456] . '<br />' . ($modSettings['enableStickyTopics'] == '1' ? '
			<img src="' . $settings['images_url'] . '/topic/normal_post_sticky.gif" alt="" align="middle" /> ' . $txt['smf96'] . '<br />' : '') . ($modSettings['pollMode'] == '1' ? '
			<img src="' . $settings['images_url'] . '/topic/normal_poll.gif" alt="" align="middle" /> ' . $txt['smf43'] : '') . '
		</td>
	</tr>
</table>';
}

function template_admin()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;
	
	echo '
<table width="100%" border="0" cellspacing="0" cellpadding="3">
	<tr>
		<td>', theme_linktree(), '</td>
	</tr>
</table>

<table width="100%" cellpadding="3" cellspacing="0" border="0" class="tborder" style="margin-bottom: 0.1ex;">
	<tr>
		<td align="center" class="titlebg" height="30">
				<b>' . $txt['hide_post_info'] . '</b>
		</td>
	</tr>
</table>

<table border="0" width="100%" cellspacing="0" cellpadding="0" class="bordercolor" style="margin-bottom: 1ex;">
	<tr><td>
		<table border="0" width="100%" cellspacing="0" cellpadding="4" class="bordercolor">
			<tr class="windowbg">
				<td width="15%">', $txt['hide_topic_all'], '</td>
				<td>', $context['hide_topic'], '</td>
				<td width="15%">', $txt['hide_post_all'], '</td>
				<td>', $context['hide_post'], '</td>
			</tr>
			<tr class="windowbg2">
				<td width="15%">', $txt['hide_topic_login'], '</td>
				<td>', $context['hide_topic_login'], '</td>
				<td width="15%">', $txt['hide_post_login'], '</td>
				<td>', $context['hide_post_login'], '</td>
			</tr>
			<tr class="windowbg">
				<td width="15%">', $txt['hide_topic_reply'], '</td>
				<td>', $context['hide_topic_reply'], '</td>
				<td width="15%">', $txt['hide_post_reply'], '</td>
				<td>', $context['hide_post_reply'], '</td>
			</tr>
			<tr class="windowbg2">
				<td width="15%">', $txt['hide_topic_karma'],'</td>
				<td>', $context['hide_topic_karma'], ' (', $context['hide_karma_min'], '-', $context['hide_karma_max'], ')</td>
				<td width="15%">', $txt['hide_post_karma'], '</td>
				<td>', $context['hide_post_karma'], ' (', $context['hide_karma_min'], '-', $context['hide_karma_max'], ')</td>
			</tr>
			<tr class="windowbg">
				<td width="15%">', $txt['hide_topic_posts'], '</td>
				<td>', $context['hide_topic_posts'], ' (', $context['hide_post_min'], '-', $context['hide_post_max'], ')</td>
				<td width="15%">', $txt['hide_post_posts'], '</td>
				<td>', $context['hide_post_posts'], ' (', $context['hide_post_min'], '-', $context['hide_post_max'], ')</td>
			</tr>';

	if (!empty($context['auto_hide_post']))
	{
		echo '
			<tr class="catbg">
				<td colspan="4" align="right">
					<form action="', $context['auto_hide_post'], '" method="POST">
						<input type="submit" value="', $txt['hide_post_auto'], '" onclick="return confirm(\'' . $txt['hide_post_confirm'] . '\');" />
						<input type="hidden" name="sc" value="', $context['session_id'], '" />
					</form>
				</td>
			</tr>';
	}

echo '
		</table>
	</td></tr>
</table>';

}

?>
