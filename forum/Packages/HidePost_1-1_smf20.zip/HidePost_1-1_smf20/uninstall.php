<?php

{
global $smcFunc;

$result = $smcFunc['db_query']('', "SHOW COLUMNS FROM {db_prefix}messages LIKE 'hiddenOption'");
if ($smcFunc['db_fetch_assoc']($result) != 0)
	$smcFunc['db_query']('', "ALTER TABLE {db_prefix}messages DROP hiddenOption, DROP hiddenValue");

$result = $smcFunc['db_query']('', "SHOW COLUMNS FROM {db_prefix}messages LIKE 'hiddenInfo'");
if ($smcFunc['db_fetch_assoc']($result) != 0) 
	$smcFunc['db_query']('', "ALTER TABLE {db_prefix}messages DROP hiddenInfo");
	
$smcFunc['db_query']('', "DELETE FROM {db_prefix}settings 
				WHERE `variable` LIKE 'allow_hiddenPost' 
					OR `variable` LIKE 'show_hiddenMessage' 
					OR `variable` LIKE 'max_hiddenValue' 
					OR `variable` LIKE 'show_hiddenColor'
					OR `variable` LIKE 'hidden_info_length'
					LIMIT 6");

$smcFunc['db_query']('', "DELETE FROM {db_prefix}board_permissions
				WHERE `permission` LIKE 'hide_post_own'
					OR `permission` LIKE 'hide_post_any'
					OR `permission` LIKE 'view_hidden_post'
					OR `permission` LIKE 'view_hidden_msg'");

}

?>
