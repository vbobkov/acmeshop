Hide Post Mod

Version 1.1 for SMF 2.0

Written By: Xiaoqing Zhou (Leaf)
Contact Info: leaf88@gmail.com
SMF Board: http://www.anetcity.com/bbs/index.php?board=125.0

This mod hides posts, including attachments, according to certain criteria when viewing posts.
It shows some hidden post messages when applicable.

Posts can be hidden by the following options:
1. Login: It requires a user to login to see the post.
2. Reply: It requires a user to reply to the topic to see the post.
3. Karma: It requires a user to have a total karma greater than or equal to a specified value to see the post.
4. Posts: It requires a user to have a number of posts greater than or equal to a specified value to see the post.
5. Moderator: It requires a user to be a moderator, global moderator or administrator to see the post.

In Admin panel, user can control the behavior of this mod:
1. Option to enable the hidden post feature.
2. Option to show hidden messages in posts if user can see the posts.
3. Set the threshold for the posts hidden by Karma and posts.
4. Option to configure hidden message color.
5. Set the maximum length of the hidden notes.

Post permissions in board:
- Hide own posts ('hide_post_own'): If a user has this permission, he will be able to hide his own posts.
- Hide any posts ('hide_post_any'): If a user has this permission, he will be able to hide others posts given that he can modify them, or he can hide his replies to other's posts. Post modification permission still applies.
- View hidden posts ('view_hidden_post'): If a user has this permission, he will be able to see all hidden posts.
- View hidden messages ('view_hidden_msg'): If a user has this permission and the global option to show hidden messages is turned off, he will be able to see the hidden messages if he can see the hidden posts.

If a user belongs to a certain allowed group, they may be able to view all hidden posts regardless whether they meet the hiding criteria or not.

This mod sets the default global settings and hiding post permssions during installation:
- Enable hiding post and show hidden messages.
- Default threshold for hiding by karma/posts is 500.
- Default hidden message color is red.
- Default maximum length of hidden notes is 500.
- Regular user and above can hiding his own or any posts if he can modify/create a post.
- Regular user and above can always see the hidden message if he can see the post.

Administrators and moderators can view hidden posts.
Administrators can diable this mod completely or configure the hidden threshold from global settings.
Hiding option is available if user clicks on "Additional Options" when posting.

This mod supports default and classic theme. If you use any language other than the supported languages (English & Simplified Chinese), you shall copy the language file HidePost.english.php to HidePost.yourlanguage.php and translate it by yourself. Then, upload that language file HidePost.yourlanguage.php to the language directory.

---------------------------------

Languages supported: English, Greek, Simplified Chinese (GB2312, utf8), Traditional Chinese (Big5, utf8)
